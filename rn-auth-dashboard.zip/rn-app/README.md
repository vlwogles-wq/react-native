# 📱 TaskManager — React Native App

Aplicativo mobile de autenticação e gerenciamento de tarefas desenvolvido com React Native + Expo.

---

## 🗂 Estrutura do Projeto

```
rn-auth-dashboard/
├── App.js                          # Ponto de entrada
├── app.json                        # Configuração Expo
├── package.json
├── babel.config.js
└── src/
    ├── theme.js                    # Design tokens (cores, espaçamento)
    ├── navigation/
    │   └── AppNavigator.js         # React Navigation (Stack)
    ├── screens/
    │   ├── LoginScreen.js          # Tela de login
    │   └── DashboardScreen.js      # Tela de dashboard + lista
    └── hooks/
        └── useStorage.js           # Hook de persistência (AsyncStorage)
```

---

## ✅ Funcionalidades Implementadas

### Tela de Login
- [x] Campo de usuário e senha
- [x] Botão de login com feedback de carregamento
- [x] Validação de campos vazios
- [x] Autenticação simulada (`admin` / `123`)
- [x] Mensagem de erro com animação de shake
- [x] Toggle de visibilidade da senha
- [x] Animação de entrada na tela

### Tela de Dashboard
- [x] Campo para adicionar itens
- [x] Botão de adicionar
- [x] **FlatList** para renderizar a lista dinamicamente
- [x] ID único por item (`timestamp + random`)
- [x] Remoção de item com confirmação (Alert)
- [x] Contador de itens
- [x] Botão "Limpar tudo"
- [x] Estado vazio estilizado
- [x] Animação de entrada de cada item
- [x] **Logout** com confirmação

### Diferenciais implementados
- [x] **Validação de campos** (não permite vazios)
- [x] **Estilização personalizada** (dark theme, cores, tipografia)
- [x] **Persistência com AsyncStorage** (dados mantidos ao fechar o app)
- [x] **Logout**
- [x] **Animações** (fade-in, spring, shake no erro)

---

## 🚀 Como Executar

### Pré-requisitos

- [Node.js](https://nodejs.org/) 18 ou superior
- [Expo CLI](https://docs.expo.dev/get-started/installation/)
- App **Expo Go** no celular ([iOS](https://apps.apple.com/app/expo-go/id982107779) / [Android](https://play.google.com/store/apps/details?id=host.exp.exponent))

### Passo a passo

```bash
# 1. Clone ou extraia o projeto
cd rn-auth-dashboard

# 2. Instale as dependências
npm install

# 3. Inicie o servidor de desenvolvimento
npx expo start
```

4. Abra o app **Expo Go** no celular e escaneie o QR code exibido no terminal.

### Alternativas de execução

```bash
# Emulador Android
npx expo start --android

# Simulador iOS (macOS apenas)
npx expo start --ios

# Navegador (web — funcionalidade limitada)
npx expo start --web
```

---

## 🔐 Credenciais de Teste

| Usuário   | Senha     |
|-----------|-----------|
| `admin`   | `123`     |
| `usuario` | `senha123`|

---

## 📦 Dependências Principais

| Pacote | Versão | Uso |
|--------|--------|-----|
| `expo` | ~50 | Plataforma de desenvolvimento |
| `react-native` | 0.73 | Framework mobile |
| `@react-navigation/native` | ^6 | Navegação entre telas |
| `@react-navigation/native-stack` | ^6 | Stack navigator |
| `@react-native-async-storage/async-storage` | 1.21 | Persistência local |

---

## 🎨 Design

O app usa um **dark theme** inspirado em interfaces modernas de produtividade:

- **Paleta**: fundo escuro (`#0F0F1A`) + superfícies em azul-noite + vermelho coral (`#E94560`) como acento
- **Tipografia**: System fonts com pesos e espaçamentos cuidadosos
- **Animações**: entrada suave com `Animated.spring` e `Animated.timing`

---

## 📋 Requisitos Técnicos Atendidos

| Requisito | Status |
|-----------|--------|
| React Native com Expo | ✅ |
| React Navigation | ✅ |
| FlatList | ✅ |
| useState | ✅ |
| Validação de campos | ✅ |
| Estilização personalizada | ✅ |
| AsyncStorage (persistência) | ✅ |
| Logout | ✅ |
| Animações | ✅ |
