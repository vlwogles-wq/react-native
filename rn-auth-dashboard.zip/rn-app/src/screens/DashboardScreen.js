// src/screens/DashboardScreen.js
import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Alert,
  Animated,
  StatusBar,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { colors, spacing, radius } from '../theme';
import { useStorage } from '../hooks/useStorage';

// ─── Item individual da lista ────────────────────────────────────────────────
function TaskItem({ item, onRemove }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(-20)).current;

  React.useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 9, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleRemove = () => {
    Alert.alert(
      'Remover item',
      `Deseja remover "${item.text}"?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: () => {
            Animated.parallel([
              Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
              Animated.timing(slideAnim, { toValue: 20, duration: 200, useNativeDriver: true }),
            ]).start(() => onRemove(item.id));
          },
        },
      ]
    );
  };

  const dateStr = new Date(item.createdAt).toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <Animated.View
      style={[
        styles.taskCard,
        { opacity: fadeAnim, transform: [{ translateX: slideAnim }] },
      ]}
    >
      <View style={styles.taskDot} />
      <View style={styles.taskContent}>
        <Text style={styles.taskText}>{item.text}</Text>
        <Text style={styles.taskDate}>🕐 {dateStr}</Text>
      </View>
      <TouchableOpacity onPress={handleRemove} style={styles.removeBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Text style={styles.removeIcon}>✕</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

// ─── Lista vazia ─────────────────────────────────────────────────────────────
function EmptyState() {
  return (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyIcon}>📋</Text>
      <Text style={styles.emptyTitle}>Nenhum item ainda</Text>
      <Text style={styles.emptyText}>Adicione itens usando o campo acima</Text>
    </View>
  );
}

// ─── Tela principal ──────────────────────────────────────────────────────────
export default function DashboardScreen({ navigation, route }) {
  const username = route?.params?.username ?? 'usuário';
  const [inputText, setInputText] = useState('');
  const [inputError, setInputError] = useState('');
  const { items, loading, addItem, removeItem, clearAll } = useStorage();
  const inputRef = useRef(null);

  const handleAdd = useCallback(() => {
    if (!inputText.trim()) {
      setInputError('Digite um item antes de adicionar.');
      inputRef.current?.shake?.();
      return;
    }
    addItem(inputText);
    setInputText('');
    setInputError('');
  }, [inputText, addItem]);

  const handleClearAll = () => {
    if (items.length === 0) return;
    Alert.alert(
      'Limpar lista',
      'Remover todos os itens?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Limpar tudo', style: 'destructive', onPress: clearAll },
      ]
    );
  };

  const handleLogout = () => {
    Alert.alert(
      'Sair',
      'Deseja fazer logout?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Sair',
          style: 'destructive',
          onPress: () => navigation.replace('Login'),
        },
      ]
    );
  };

  const renderItem = useCallback(
    ({ item }) => <TaskItem item={item} onRemove={removeItem} />,
    [removeItem]
  );

  const keyExtractor = useCallback((item) => item.id, []);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Olá, {username} 👋</Text>
            <Text style={styles.headerTitle}>Minha Lista</Text>
          </View>
          <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
            <Text style={styles.logoutIcon}>⏻</Text>
          </TouchableOpacity>
        </View>

        {/* Stat badge */}
        <View style={styles.statRow}>
          <View style={styles.statBadge}>
            <Text style={styles.statNumber}>{items.length}</Text>
            <Text style={styles.statLabel}> {items.length === 1 ? 'item' : 'itens'}</Text>
          </View>
          {items.length > 0 && (
            <TouchableOpacity onPress={handleClearAll} style={styles.clearBtn}>
              <Text style={styles.clearText}>Limpar tudo</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Input */}
        <View style={styles.inputSection}>
          <View style={[styles.inputWrapper, !!inputError && styles.inputWrapperError]}>
            <TextInput
              ref={inputRef}
              style={styles.input}
              placeholder="Adicionar novo item..."
              placeholderTextColor={colors.textDim}
              value={inputText}
              onChangeText={v => { setInputText(v); setInputError(''); }}
              returnKeyType="done"
              onSubmitEditing={handleAdd}
              maxLength={120}
            />
          </View>
          <TouchableOpacity style={styles.addBtn} onPress={handleAdd} activeOpacity={0.85}>
            <Text style={styles.addIcon}>＋</Text>
          </TouchableOpacity>
        </View>

        {!!inputError && (
          <Text style={styles.inputErrorText}>⚠️  {inputError}</Text>
        )}

        {/* Divider */}
        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerLabel}>Lista de itens</Text>
          <View style={styles.dividerLine} />
        </View>

        {/* FlatList */}
        <FlatList
          data={items}
          keyExtractor={keyExtractor}
          renderItem={renderItem}
          ListEmptyComponent={!loading && <EmptyState />}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  greeting: {
    fontSize: 13,
    color: colors.textMuted,
    marginBottom: 2,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.text,
    letterSpacing: 0.5,
  },
  logoutBtn: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutIcon: {
    fontSize: 18,
    color: colors.accent,
  },
  statRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
    gap: spacing.md,
  },
  statBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
    backgroundColor: colors.accentDim,
    borderRadius: radius.full,
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: colors.accentBorder,
  },
  statNumber: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.accent,
  },
  statLabel: {
    fontSize: 13,
    color: colors.accent,
    opacity: 0.8,
  },
  clearBtn: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
  },
  clearText: {
    fontSize: 12,
    color: colors.textMuted,
    textDecorationLine: 'underline',
  },
  inputSection: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
    marginBottom: 4,
  },
  inputWrapper: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 50,
    justifyContent: 'center',
  },
  inputWrapperError: {
    borderColor: colors.accent,
  },
  input: {
    color: colors.text,
    fontSize: 15,
  },
  addBtn: {
    width: 50,
    height: 50,
    borderRadius: radius.md,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: colors.accent,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 5,
  },
  addIcon: {
    fontSize: 24,
    color: colors.white,
    fontWeight: '300',
    lineHeight: 28,
  },
  inputErrorText: {
    color: colors.accent,
    fontSize: 12,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.sm,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    marginVertical: spacing.md,
    gap: spacing.sm,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  dividerLabel: {
    fontSize: 11,
    color: colors.textDim,
    textTransform: 'uppercase',
    letterSpacing: 1.5,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
    flexGrow: 1,
  },
  // Task card
  taskCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.sm,
  },
  taskDot: {
    width: 8,
    height: 8,
    borderRadius: radius.full,
    backgroundColor: colors.accent,
    opacity: 0.7,
  },
  taskContent: {
    flex: 1,
  },
  taskText: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '500',
  },
  taskDate: {
    color: colors.textDim,
    fontSize: 11,
    marginTop: 2,
  },
  removeBtn: {
    width: 28,
    height: 28,
    borderRadius: radius.full,
    backgroundColor: 'rgba(233,69,96,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  removeIcon: {
    color: colors.accent,
    fontSize: 12,
    fontWeight: '700',
  },
  // Empty state
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl,
    gap: spacing.sm,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: spacing.sm,
  },
  emptyTitle: {
    color: colors.textMuted,
    fontSize: 18,
    fontWeight: '700',
  },
  emptyText: {
    color: colors.textDim,
    fontSize: 13,
    textAlign: 'center',
  },
});
