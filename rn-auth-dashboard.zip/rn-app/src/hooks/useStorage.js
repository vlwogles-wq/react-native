// src/hooks/useStorage.js
import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ITEMS_KEY = '@dashboard_items';

export function useStorage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load from storage on mount
  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(ITEMS_KEY);
        if (stored) setItems(JSON.parse(stored));
      } catch (e) {
        console.warn('Failed to load items:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Persist whenever items change
  const persist = useCallback(async (newItems) => {
    try {
      await AsyncStorage.setItem(ITEMS_KEY, JSON.stringify(newItems));
    } catch (e) {
      console.warn('Failed to save items:', e);
    }
  }, []);

  const addItem = useCallback((text) => {
    const newItem = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    const updated = [newItem, ...items];
    setItems(updated);
    persist(updated);
    return newItem;
  }, [items, persist]);

  const removeItem = useCallback((id) => {
    const updated = items.filter(item => item.id !== id);
    setItems(updated);
    persist(updated);
  }, [items, persist]);

  const clearAll = useCallback(() => {
    setItems([]);
    AsyncStorage.removeItem(ITEMS_KEY);
  }, []);

  return { items, loading, addItem, removeItem, clearAll };
}
