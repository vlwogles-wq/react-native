// src/theme.js
export const colors = {
  bg: '#0F0F1A',
  surface: '#1A1A2E',
  surfaceLight: '#16213E',
  accent: '#E94560',
  accentDim: 'rgba(233, 69, 96, 0.15)',
  accentBorder: 'rgba(233, 69, 96, 0.4)',
  gold: '#F5A623',
  text: '#EAEAEA',
  textMuted: '#7A7A9A',
  textDim: '#4A4A6A',
  border: 'rgba(255,255,255,0.07)',
  success: '#2ECC71',
  danger: '#E94560',
  white: '#FFFFFF',
};

export const fonts = {
  heading: 'System',
  body: 'System',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
  full: 999,
};
